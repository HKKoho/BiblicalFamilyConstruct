/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { Hero } from './components/Hero';
import { InputArea } from './components/InputArea';
import { ChatDisplay } from './components/LivePreview';
import { TopicRibbon } from './components/CreationHistory';
import { getBiblicalAdvice, ChatMessage, TopicContext } from './services/gemini';
import { ChevronLeftIcon } from '@heroicons/react/24/outline';

const TOPICS: TopicContext[] = [
  { id: 'insecurity', title: 'Overcoming Insecurity', description: 'Find your identity and worth in God, not in worldly standards.', verses: 'Psalm 139:14, Ephesians 2:10' },
  { id: 'loneliness', title: 'Overcoming Loneliness', description: 'Experience the presence of the Friend who sticks closer than a brother.', verses: 'Deuteronomy 31:6, Matthew 28:20' },
  { id: 'stress', title: 'Overcoming Stress', description: 'Find rest for your soul in His grace amidst the chaos of life.', verses: 'Matthew 11:28-30, Philippians 4:6-7' },
  { id: 'anxiety', title: 'Overcoming Anxiety', description: 'Cast your cares on Him, for He cares deeply for you.', verses: '1 Peter 5:7, Isaiah 41:10' },
  { id: 'guilt', title: 'Overcoming Guilt & Shame', description: 'Embrace the freedom that comes from His forgiveness.', verses: 'Romans 8:1, 1 John 1:9' },
  { id: 'anger', title: 'Overcoming Anger', description: 'Learn to be slow to speak and slow to become angry.', verses: 'James 1:19-20, Ephesians 4:26' },
  { id: 'depression', title: 'Overcoming Depression', description: 'The Lord is close to the brokenhearted and saves the crushed in spirit.', verses: 'Psalm 34:18, Psalm 42:11' },
  { id: 'trauma', title: 'Overcoming Trauma', description: 'He heals the brokenhearted and binds up their wounds.', verses: 'Psalm 147:3, Isaiah 61:1-3' },
  { id: 'exhaustion', title: 'Overcoming Exhaustion', description: 'Those who hope in the Lord will renew their strength.', verses: 'Isaiah 40:29-31, Galatians 6:9' },
  { id: 'sorrow', title: 'Overcoming Sorrow', description: 'Weeping may stay for the night, but rejoicing comes in the morning.', verses: 'Psalm 30:5, Revelation 21:4' },
];

const App: React.FC = () => {
  const [activeTopic, setActiveTopic] = useState<TopicContext | null>(null);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSelectTopic = (topic: TopicContext) => {
    setActiveTopic(topic);
    setChatHistory([]); // Start fresh chat
  };

  const handleBack = () => {
    setActiveTopic(null);
    setChatHistory([]);
  };

  const handleSendMessage = async (text: string) => {
    if (!activeTopic) return;

    const newMessage: ChatMessage = { role: 'user', text };
    const updatedHistory = [...chatHistory, newMessage];
    
    setChatHistory(updatedHistory);
    setIsLoading(true);

    try {
      // Call Gemini
      const responseText = await getBiblicalAdvice(updatedHistory, text, activeTopic);
      
      const botMessage: ChatMessage = { role: 'model', text: responseText };
      setChatHistory(prev => [...prev, botMessage]);
    } catch (error) {
      console.error("Failed to get advice", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-[100dvh] flex flex-col bg-ambient overflow-hidden relative">
      
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-900/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-purple-900/10 rounded-full blur-3xl"></div>
      </div>

      {!activeTopic ? (
        /* HOME VIEW: Topic Grid */
        <div className="flex-1 overflow-y-auto z-10">
          <Hero />
          
          <div className="max-w-6xl mx-auto px-4 pb-20">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {TOPICS.map((topic) => (
                <button
                  key={topic.id}
                  onClick={() => handleSelectTopic(topic)}
                  className="group relative overflow-hidden bg-zinc-900/40 hover:bg-zinc-800/60 border border-zinc-800 hover:border-blue-500/30 rounded-xl p-6 text-left transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
                >
                  <div className="absolute top-0 left-0 w-1 h-full bg-blue-500/0 group-hover:bg-blue-500/50 transition-colors"></div>
                  <h3 className="text-lg font-serif font-medium text-zinc-100 mb-2 group-hover:text-blue-200">
                    {topic.title}
                  </h3>
                  <p className="text-sm text-zinc-500 group-hover:text-zinc-400 line-clamp-2">
                    {topic.description}
                  </p>
                  <div className="mt-4 flex items-center text-xs text-blue-500/0 group-hover:text-blue-400 transition-colors">
                    <span>Start Session</span>
                    <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <footer className="text-center py-8 text-zinc-600 text-xs">
            <p>Biblical Emotional Healing App • {new Date().getFullYear()}</p>
          </footer>
        </div>
      ) : (
        /* CHAT VIEW */
        <div className="flex flex-col h-full z-10 animate-in fade-in duration-500">
          {/* Header */}
          <div className="flex-shrink-0 bg-zinc-950/80 backdrop-blur-md border-b border-zinc-800 px-4 py-3 flex items-center justify-between">
            <button 
              onClick={handleBack}
              className="flex items-center text-zinc-400 hover:text-white transition-colors text-sm font-medium"
            >
              <ChevronLeftIcon className="w-5 h-5 mr-1" />
              Back
            </button>
            <span className="text-sm font-semibold text-zinc-200 hidden sm:block">Soul Care Session</span>
            <div className="w-16"></div> {/* Spacer for centering */}
          </div>

          {/* Quick Topic Switcher */}
          <TopicRibbon topics={TOPICS} activeTopicId={activeTopic.id} onSelect={handleSelectTopic} />

          {/* Chat Content */}
          <ChatDisplay 
            messages={chatHistory} 
            topic={activeTopic} 
            isLoading={isLoading} 
          />

          {/* Input Area */}
          <div className="flex-shrink-0 p-4 pb-6 bg-gradient-to-t from-[#09090b] to-transparent">
             <InputArea onSendMessage={handleSendMessage} isLoading={isLoading} />
          </div>
        </div>
      )}
    </div>
  );
};

export default App;