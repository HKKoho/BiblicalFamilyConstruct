/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useEffect, useRef } from 'react';
import { ChatMessage, TopicContext } from '../services/gemini';
import { SparklesIcon, UserCircleIcon, BookOpenIcon } from '@heroicons/react/24/outline';

interface ChatDisplayProps {
  messages: ChatMessage[];
  topic: TopicContext;
  isLoading: boolean;
}

// Internal component to render formatted markdown-like text
const FormattedText: React.FC<{ text: string }> = ({ text }) => {
  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];
  
  // Helper for bold text
  const renderRichText = (content: string) => {
      return content.split(/(\*\*.*?\*\*)/).map((part, i) => 
          part.startsWith('**') && part.endsWith('**') 
              ? <strong key={i} className="font-semibold text-blue-200">{part.slice(2, -2)}</strong> 
              : part
      );
  };

  lines.forEach((line, i) => {
      const trimmed = line.trim();
      
      if (!trimmed) {
          elements.push(<div key={i} className="h-2" />);
          return;
      }

      // Blockquote (Scripture)
      if (trimmed.startsWith('>')) {
          elements.push(
              <div key={i} className="relative group my-4">
                  <div className="absolute inset-0 bg-blue-500/10 blur-xl rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <div className="relative flex gap-3 bg-gradient-to-r from-blue-950/40 to-transparent border-l-2 border-blue-400 p-4 rounded-r-xl">
                    <BookOpenIcon className="w-5 h-5 text-blue-400 flex-shrink-0 mt-1" />
                    <div className="text-blue-100/90 italic font-serif leading-relaxed text-base">
                        {renderRichText(trimmed.replace(/^>\s?/, ''))}
                    </div>
                  </div>
              </div>
          );
          return;
      }

      // List Item (Actionable steps)
      if (trimmed.match(/^[\*\-]\s/) || trimmed.match(/^\d+\.\s/)) {
          const content = trimmed.replace(/^([\*\-]\s|\d+\.\s)/, '');
          elements.push(
              <div key={i} className="flex gap-3 items-start my-2 bg-zinc-800/30 p-3 rounded-lg border border-zinc-800/50 hover:border-zinc-700 transition-colors">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-2 flex-shrink-0 shadow-[0_0_8px_rgba(96,165,250,0.6)]" />
                  <span className="text-zinc-200 leading-relaxed">{renderRichText(content)}</span>
              </div>
          );
          return;
      }

      // Header
      if (trimmed.startsWith('#') || (trimmed.endsWith(':') && trimmed.length < 60)) {
          elements.push(
              <h4 key={i} className="text-zinc-100 font-semibold mt-5 mb-2 text-lg tracking-tight">
                  {renderRichText(trimmed.replace(/^#+\s?/, ''))}
              </h4>
          );
          return;
      }

      // Default Paragraph
      elements.push(
          <p key={i} className="text-zinc-300 leading-relaxed mb-2">
              {renderRichText(trimmed)}
          </p>
      );
  });

  return <div className="space-y-1">{elements}</div>;
};

export const ChatDisplay: React.FC<ChatDisplayProps> = ({ messages, topic, isLoading }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-6" ref={scrollRef}>
      <div className="max-w-3xl mx-auto space-y-6">
        
        {/* Welcome / Context Card */}
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 mb-8 text-center">
            <div className="w-12 h-12 bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <SparklesIcon className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-xl font-serif text-zinc-100 mb-2">{topic.title}</h3>
            <p className="text-zinc-400 text-sm leading-relaxed mb-4">{topic.description}</p>
            <div className="inline-block px-4 py-2 bg-zinc-950 rounded-lg border border-zinc-800/50">
                <p className="text-xs text-zinc-500 font-mono italic">"{topic.verses}"</p>
            </div>
        </div>

        {/* Messages */}
        {messages.map((msg, idx) => (
          <div 
            key={idx} 
            className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
          >
            {/* Avatar */}
            <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${msg.role === 'user' ? 'bg-zinc-700' : 'bg-blue-900/30'}`}>
                {msg.role === 'user' ? (
                    <UserCircleIcon className="w-5 h-5 text-zinc-300" />
                ) : (
                    <SparklesIcon className="w-4 h-4 text-blue-400" />
                )}
            </div>

            {/* Bubble */}
            <div 
                className={`
                    max-w-[90%] sm:max-w-[85%] px-5 py-4 rounded-2xl text-sm sm:text-base shadow-sm
                    ${msg.role === 'user' 
                        ? 'bg-zinc-800 text-zinc-100 rounded-tr-sm whitespace-pre-wrap leading-relaxed' 
                        : 'bg-zinc-900/80 border border-zinc-800 text-zinc-300 rounded-tl-sm'
                    }
                `}
            >
                {msg.role === 'model' ? (
                  <FormattedText text={msg.text} />
                ) : (
                  msg.text
                )}
            </div>
          </div>
        ))}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-900/30 flex items-center justify-center">
                <SparklesIcon className="w-4 h-4 text-blue-400" />
            </div>
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl rounded-tl-sm px-5 py-4 flex items-center space-x-1">
                <div className="w-2 h-2 bg-blue-500/50 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></div>
                <div className="w-2 h-2 bg-blue-500/50 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></div>
                <div className="w-2 h-2 bg-blue-500/50 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></div>
            </div>
          </div>
        )}

        <div className="h-4"></div>
      </div>
    </div>
  );
};