/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { TopicContext } from '../services/gemini';

interface TopicRibbonProps {
  topics: TopicContext[];
  activeTopicId: string | null;
  onSelect: (topic: TopicContext) => void;
}

export const TopicRibbon: React.FC<TopicRibbonProps> = ({ topics, activeTopicId, onSelect }) => {
  return (
    <div className="w-full border-b border-zinc-800 bg-[#09090b]/95 backdrop-blur z-20 sticky top-0">
      <div className="max-w-7xl mx-auto">
        <div className="flex overflow-x-auto no-scrollbar py-3 px-4 gap-2">
            {topics.map((topic) => {
                const isActive = topic.id === activeTopicId;
                return (
                    <button
                        key={topic.id}
                        onClick={() => onSelect(topic)}
                        className={`
                            whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-medium transition-all duration-200 border
                            ${isActive 
                                ? 'bg-blue-900/30 border-blue-500/50 text-blue-100' 
                                : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-300 hover:border-zinc-700'
                            }
                        `}
                    >
                        {topic.title.replace('Overcoming ', '')}
                    </button>
                );
            })}
        </div>
      </div>
    </div>
  );
};