/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';

export const Hero: React.FC = () => {
  return (
    <div className="text-center relative z-10 max-w-4xl mx-auto px-4 pt-12 pb-8">
      <div className="mb-4 flex justify-center">
        <span className="px-3 py-1 rounded-full bg-blue-900/30 border border-blue-800/50 text-blue-200 text-xs font-medium tracking-wider uppercase">
          Biblical Emotional Healing
        </span>
      </div>
      <h1 className="text-4xl sm:text-5xl md:text-6xl font-serif font-medium tracking-tight text-white mb-6">
        Find <span className="text-blue-200 italic">Peace</span> in the Storm
      </h1>
      <p className="text-base sm:text-lg text-zinc-400 max-w-2xl mx-auto leading-relaxed font-light">
        Life brings emotional challenges that can feel overwhelming. Select a topic below to explore biblical wisdom, find comfort in scripture, and receive personalized guidance for your journey.
      </p>
    </div>
  );
};