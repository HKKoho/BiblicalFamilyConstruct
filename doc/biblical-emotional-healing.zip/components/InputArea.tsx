/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useEffect } from 'react';
import { PaperAirplaneIcon } from '@heroicons/react/24/solid';

interface InputAreaProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
  placeholder?: string;
}

export const InputArea: React.FC<InputAreaProps> = ({ onSendMessage, isLoading, placeholder = "Share what's on your heart..." }) => {
  const [input, setInput] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (input.trim() && !isLoading) {
      onSendMessage(input.trim());
      setInput("");
      // Reset height
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 150)}px`;
    }
  }, [input]);

  return (
    <div className="w-full max-w-3xl mx-auto">
      <form 
        onSubmit={handleSubmit}
        className="relative flex items-end gap-2 bg-zinc-900/80 backdrop-blur-md border border-zinc-700 focus-within:border-blue-500/50 rounded-2xl p-2 shadow-lg transition-colors duration-300"
      >
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={isLoading}
          rows={1}
          className="w-full bg-transparent text-zinc-100 placeholder-zinc-500 text-sm sm:text-base p-3 focus:outline-none resize-none max-h-[150px] overflow-y-auto scrollbar-hide"
        />
        
        <button
          type="button"
          onClick={() => handleSubmit()}
          disabled={!input.trim() || isLoading}
          className={`
            p-3 rounded-xl flex-shrink-0 transition-all duration-200
            ${input.trim() && !isLoading
              ? 'bg-blue-600 text-white hover:bg-blue-500 shadow-md transform hover:scale-105' 
              : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'
            }
          `}
        >
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            <PaperAirplaneIcon className="w-5 h-5" />
          )}
        </button>
      </form>
      <div className="text-center mt-2">
         <p className="text-[10px] text-zinc-600">AI can make mistakes. Please consult a professional for serious medical or mental health concerns.</p>
      </div>
    </div>
  );
};